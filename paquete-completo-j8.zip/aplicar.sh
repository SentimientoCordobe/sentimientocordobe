#!/usr/bin/env bash
# Uso: ./aplicar.sh /ruta/a/tu/sentimientocordobe
set -e
REPO="${1:?Indica la ruta de tu repo}"
DIR="$(cd "$(dirname "$0")" && pwd)"
cp "$DIR/src/data/"*.ts "$DIR/src/data/noticias.manual.json" "$REPO/src/data/"
cp "$DIR/api/votes.ts" "$REPO/api/"
mkdir -p "$REPO/public/images/noticias"
cp "$DIR/public/images/noticias/"* "$REPO/public/images/noticias/"
cd "$REPO"
pnpm install --frozen-lockfile >/dev/null
pnpm build
git add -A
git commit -m "J10 Leganés 0-1 Córdoba: noticias, clasificación, calendario, encuestas y vídeos"
echo "Commit creado. Revisa con 'git show' y luego: git push"
