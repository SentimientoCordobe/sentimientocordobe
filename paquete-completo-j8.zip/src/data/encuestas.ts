export interface OpcionEncuesta {
  id: string;
  label: string;
  dorsal?: number; // para las fichas de jugador de la encuesta MVP
}

export interface Encuesta {
  id: string;
  pregunta: string;
  cierre?: string; // fecha orientativa de cierre, solo informativa en la UI
  opciones: OpcionEncuesta[];
}

export const encuestaResultado: Encuesta = {
  id: "resultado-j11-Eibar",
  pregunta: "Córdoba CF vs SD Eibar — Jornada 11, sáb 24 oct, Nuevo Arcángel",
  cierre: "24/10/2026",
  opciones: [
    { id: "local", label: "Gana el Córdoba" },
    { id: "empate", label: "Empate" },
    { id: "visitante", label: "Gana el Eibar" },
  ],
};

// Encuesta de MVP del último partido disputado (Leganés 0-1 Córdoba, J10).
export const encuestaMVP: Encuesta = {
  id: "mvp-j10-Leganes",
  pregunta: "Quién fue el MEJOR del Leganés - Córdoba (Jornada 10)",
  opciones: [
    { id: "Eder", label: "Eder", dorsal: 28 },
    { id: "Carracedo", label: "Carracedo", dorsal: 23 },
    { id: "Iker Álvarez", label: "Iker Álvarez", dorsal: 1 },
    { id: "Víctor Sánchez", label: "Víctor Sánchez", dorsal: 15 },
    { id: "Percan", label: "Percan", dorsal: 9 },
    { id: "Isma Ruiz", label: "Isma Ruiz", dorsal: 8 },
    { id: "Adnane Ghailan", label: "Adnane Ghailan", dorsal: 14 },
    { id: "Álex Martín", label: "Álex Martín", dorsal: 4 },
  ],
};
