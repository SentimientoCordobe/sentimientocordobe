export interface Video {
  id: string;
  titulo: string;
  resumen: string;
  miniatura: string;
  fecha: string;
  youtube: string;
}

export const videos: Video[] = [
  {
    id: "7naZ6iO0OdU",
    titulo: "CD LEGANÉS 0 - 1 CÓRDOBA CF | RESUMEN LALIGA HYPERMOTION",
    resumen: "Jornada 10 · Victoria 0-1 en Butarque con gol de Eder y primera portería a cero de la temporada.",
    miniatura: "https://img.youtube.com/vi/7naZ6iO0OdU/maxresdefault.jpg",
    fecha: "16 Oct 2026",
    youtube: "https://www.youtube.com/watch?v=7naZ6iO0OdU"
  },
  {
    id: "2dq5JQ-ucp8",
    titulo: "CD ELDENSE 2 - 1 CÓRDOBA CF | RESUMEN LALIGA HYPERMOTION",
    resumen: "Jornada 9 · Derrota 2-1 en Elda, con penalti de Fidel en el último minuto.",
    miniatura: "https://img.youtube.com/vi/2dq5JQ-ucp8/maxresdefault.jpg",
    fecha: "10 Oct 2026",
    youtube: "https://www.youtube.com/watch?v=2dq5JQ-ucp8"
  },
  {
    id: "aLp7Gjc-TGY",
    titulo: "CÓRDOBA CF 3 - 2 CD TENERIFE | RESUMEN LALIGA HYPERMOTION",
    resumen: "Jornada 8 · Victoria 3-2 ante el Tenerife en el Nuevo Arcángel, con goles de Eder, Percan e Isma Ruiz.",
    miniatura: "https://img.youtube.com/vi/aLp7Gjc-TGY/maxresdefault.jpg",
    fecha: "05 Oct 2026",
    youtube: "https://www.youtube.com/watch?v=aLp7Gjc-TGY"
  },
  
   {
    id: "CVlrXw9rSWE",
    titulo: " VALLADOLID 3 - 1 CÓRDOBA CF | RESUMEN LALIGA HYPERMOTION",
    resumen: "El Valladolid rompió su mala racha",
    miniatura: "https://img.youtube.com/vi/CVlrXw9rSWE/maxresdefault.jpg",
    fecha: "27 Sep 2026",
    youtube: "https://www.youtube.com/watch?v=CVlrXw9rSWE"
  },
  {
    id: "ywOyR9ZtTIg",
    titulo: " ALBACETE 1- 2 CÓRDOBA CF | RESUMEN LALIGA HYPERMOTION",
    resumen: "El CÓRDOBA firmó su primera victoria en casa",
    miniatura: "https://img.youtube.com/vi/ywOyR9ZtTIg/maxresdefault.jpg",
    fecha: "18 Sep 2026",
    youtube: "https://www.youtube.com/watch?v=ywOyR9ZtTIg"
  },
  {
    id: "GG660uVUp_Q",
    titulo: "ASÍ se VIVE un PARTIDO en PALCO VIP del CÓRDOBA CF",
    resumen: "Viví una nueva experiencia viendo al Córdoba CF desde el Palco VIP del Estadio El Arcángel. En este vídeo enseño cómo es el palco VIP, el ambiente del partido Córdoba CF vs Real Sociedad B (0-2) y cómo se vivió el encuentro desde dentro. ¡No te lo pierdas!",
    miniatura: "https://img.youtube.com/vi/GG660uVUp_Q/maxresdefault.jpg",
    fecha: "22 Mar 2026",
    youtube: "https://www.youtube.com/watch?v=GG660uVUp_Q"
  },
  {
    id: "2iCwBk3JSYw",
    titulo: "DERBI DE RIVALIDAD ALMERÍA-CÓRDOBA ON TOUR",
    resumen: "El Córdoba cayó en el campo, pero en la grada la afición volvió a demostrar que nunca pierde. En este vídeo te cuento la historia que casi nadie conoce sobre el origen de esta rivalidad y te muestro la realidad del partido desde dentro: ambiente, corteo, tensión y el cruce entre aficiones. ¡No te lo pierdas!",
    miniatura: "https://img.youtube.com/vi/2iCwBk3JSYw/maxresdefault.jpg",
    fecha: "23 Feb 2026",
    youtube: "https://www.youtube.com/watch?v=2iCwBk3JSYw"
  },
  {
    id: "uVZkznixBEE",
    titulo: "ON TOUR LEGANÉS | PENALTI EN EL 90’ Y…",
    resumen: "Nuevo OnTour, esta vez rumbo a Leganés. Visitamos la ciudad, conocimos el estadio y vivimos desde dentro el ambientazo del gran desplazamiento cordobesista. Una vez más, la afición estuvo de 10.",
    miniatura: "https://img.youtube.com/vi/uVZkznixBEE/maxresdefault.jpg",
    fecha: "11 Dic 2025",
    youtube: "https://www.youtube.com/watch?v=uVZkznixBEE"
  },
  {
    id: "wlfQHoZOccs",
    titulo: "ON TOUR MÁLAGA | AMBIENTAZO DE DERBI Y PENALTI EN EL 90’",
    resumen: "Ambiente espectacular, previa increíble, corteo, bengaleo y animación brutal en las gradas. Tras una expulsión polémica, el Córdoba jugó toda la segunda parte con 10 futbolistas… ¡pero jamás se rindió! Y cuando todo parecía perdido, llegó el milagro… GOL en el MINUTO 101 😳 tras 12 minutos añadidos, para poner el 2-2 final y sacar un punto de oro.",
    miniatura: "https://img.youtube.com/vi/wlfQHoZOccs/maxresdefault.jpg",
    fecha: "10 Nov 2025",
    youtube: "https://www.youtube.com/watch?v=wlfQHoZOccs"
  }
]
