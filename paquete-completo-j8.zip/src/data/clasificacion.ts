export interface EquipoClasificacion {
  posicion: number
  equipo: string
  puntos: number
  pj?: number
  pg?: number
  pe?: number
  pp?: number
  gf?: number
  gc?: number
  dg?: number

  esCordoba?: boolean;
}

// Clasificación de LALIGA HYPERMOTION 2026/27, PROVISIONAL tras la jornada 10
// (fuente: alargue.com, tras el Leganés 0-1 Córdoba). CD Tenerife y Celta
// Fortuna aparecen con 9 partidos: les falta por jugar su partido de la J10.
export const clasificacion: EquipoClasificacion[] = [
  { posicion: 1, equipo: "UD Almería", puntos: 24, pj: 10, pg: 8, pe: 0, pp: 2, gf: 20, gc: 7, dg: 13 },
  { posicion: 2, equipo: "CD Castellón", puntos: 23, pj: 10, pg: 7, pe: 2, pp: 1, gf: 18, gc: 4, dg: 14 },
  { posicion: 3, equipo: "SD Eibar", puntos: 22, pj: 10, pg: 7, pe: 1, pp: 2, gf: 20, gc: 11, dg: 9 },
  { posicion: 4, equipo: "Real Sporting", puntos: 19, pj: 10, pg: 6, pe: 1, pp: 3, gf: 11, gc: 9, dg: 2 },
  { posicion: 5, equipo: "RCD Mallorca", puntos: 18, pj: 10, pg: 5, pe: 3, pp: 2, gf: 12, gc: 5, dg: 7 },
  { posicion: 6, equipo: "Girona FC", puntos: 18, pj: 10, pg: 5, pe: 3, pp: 2, gf: 16, gc: 9, dg: 7 },
  { posicion: 7, equipo: "Burgos CF", puntos: 17, pj: 10, pg: 5, pe: 2, pp: 3, gf: 13, gc: 10, dg: 3 },
  { posicion: 8, equipo: "Granada CF", puntos: 17, pj: 10, pg: 5, pe: 2, pp: 3, gf: 16, gc: 13, dg: 3 },
  { posicion: 9, equipo: "Real Oviedo", puntos: 17, pj: 10, pg: 5, pe: 2, pp: 3, gf: 13, gc: 10, dg: 3 },
  { posicion: 10, equipo: "CE Sabadell", puntos: 16, pj: 10, pg: 4, pe: 4, pp: 2, gf: 10, gc: 8, dg: 2 },
  { posicion: 11, equipo: "CD Eldense", puntos: 14, pj: 10, pg: 4, pe: 2, pp: 4, gf: 13, gc: 13, dg: 0 },
  { posicion: 12, equipo: "Real Valladolid", puntos: 12, pj: 10, pg: 3, pe: 3, pp: 4, gf: 15, gc: 14, dg: 1 },
  { posicion: 13, equipo: "CD Tenerife", puntos: 12, pj: 9, pg: 3, pe: 3, pp: 3, gf: 11, gc: 13, dg: -2 },
  { posicion: 14, equipo: "Córdoba CF", puntos: 12, pj: 10, pg: 4, pe: 0, pp: 6, gf: 15, gc: 19, dg: -4, esCordoba: true },
  { posicion: 15, equipo: "Celta Fortuna", puntos: 11, pj: 9, pg: 3, pe: 2, pp: 4, gf: 14, gc: 15, dg: -1 },
  { posicion: 16, equipo: "UD Las Palmas", puntos: 11, pj: 10, pg: 3, pe: 2, pp: 5, gf: 13, gc: 19, dg: -6 },
  { posicion: 17, equipo: "CD Leganés", puntos: 11, pj: 10, pg: 3, pe: 2, pp: 5, gf: 6, gc: 15, dg: -9 },
  { posicion: 18, equipo: "FC Andorra", puntos: 10, pj: 10, pg: 3, pe: 1, pp: 6, gf: 13, gc: 17, dg: -4 },
  { posicion: 19, equipo: "Real Sociedad B", puntos: 8, pj: 10, pg: 2, pe: 2, pp: 6, gf: 14, gc: 21, dg: -7 },
  { posicion: 20, equipo: "Cádiz CF", puntos: 7, pj: 10, pg: 1, pe: 4, pp: 5, gf: 11, gc: 13, dg: -2 },
  { posicion: 21, equipo: "AD Ceuta FC", puntos: 5, pj: 10, pg: 1, pe: 2, pp: 7, gf: 9, gc: 22, dg: -13 },
  { posicion: 22, equipo: "Albacete BP", puntos: 1, pj: 10, pg: 0, pe: 1, pp: 9, gf: 6, gc: 22, dg: -16 },
];
